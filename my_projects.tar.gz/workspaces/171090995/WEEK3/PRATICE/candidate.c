#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

typedef struct
{
    string name;
    int votes;
} candidate;
candidate get_candidate(string prompt);
int main(void)
{
    int candidate_number;
    do
    {
        candidate_number = get_int("Enter candidate amount: ");
    }
    while (candidate_number <= 0);
    candidate candidates[candidate_number];

    int a = 0;
    for (int i = 0; i < candidate_number; i++)
    {
        candidates[i] = get_candidate("Enter a candidate: ");
        if (candidates[i].votes > candidates[a].votes)
        {
            a = i;
        }
    }

    printf("%s\n", candidates[a].name);
    printf("%i\n", candidates[a].votes);
}

candidate get_candidate(string prompt)
{
    candidate c;
    c.name = get_string("Enter a name: ");
    c.votes = get_int("Enter the votes: ");
    return c;
}
