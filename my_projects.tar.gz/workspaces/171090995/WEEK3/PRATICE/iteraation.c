#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

void draw(int size);
int main (void)
{
    int heigth = get_int("Enter height: ");
    draw(heigth);

}

void draw(int size){
    for(int i = 0; i < size ; i++){
        for(int j = 0 ; j < i+1 ; j++){
            printf("#");
        }
        printf("\n");
    }
}
