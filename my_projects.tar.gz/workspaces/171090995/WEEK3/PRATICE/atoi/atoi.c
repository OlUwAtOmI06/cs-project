#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int convert(string input);

int main(void)
{
    string input = get_string("Enter a positive integer: ");

    for (int i = 0, n = strlen(input); i < n; i++)
    {
        if (!isdigit(input[i]))
        {
            printf("Invalid Input!\n");
            return 1;
        }
    }

    // Convert string to int
    printf("%i\n", convert(input));
}

int convert(string input)
{
    // TODO
    int length = strlen(input); // get the size of the array
    int inital = length -1; // get the array index of the last char
    char last_c; // last char variable
    last_c = input[inital];// put the last char to it's appropriate index
    if(length == 0){ // make the execption case
        return 0;
    }
    int last_value = last_c - '0';
    input[inital] = '\0';
   return last_value + 10 * convert(input);

}
