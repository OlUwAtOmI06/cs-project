#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

void draw(int size);
int main (void)
{
    int heigth = get_int("Enter height: ");
    draw(heigth);

}

void draw(int size){
    if(size == 0){
        return ;
    }
    return
}
