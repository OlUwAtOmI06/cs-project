#include <cs50.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h>


int factorial(int number);

int main(){
    int n = get_int("Type a number: ");

}

//output-type name (input-type)
int factorial(int number){
    if(number == 1){
        return 1;
    }
    return number * factorial(number - 1);
}
