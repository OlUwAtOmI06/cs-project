#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "wav.h"

const int HEADER_SIZE = 44;
int check_format(WAVHEADER header);
int get_block_size(WAVHEADER header);

int main(int argc, char *argv[])
{
    // Ensure proper usage
    // TODO #1
    if (argc != 3)
    {
        printf("Usage: ./reverse input.wav output.wav\n");
        return 1;
    }

    // Open input file for reading
    // TODO #2
    FILE *input = fopen(argv[1], "r");
    if (input == NULL)
    {
        printf("Could not open file.\n");
        return 1;
    }

    // Read header
    // TODO #3
    WAVHEADER header;
    size_t bytesRead = fread(&header, 1, sizeof(WAVHEADER), input);
    if (bytesRead != HEADER_SIZE)
    {
        // If we couldn't read 44 bytes, report an error
        perror("Error reading header");
        return 1;
    }

    // Use check_format to ensure WAV format
    // TODO #4
    check_format(header);

    // Open output file for writing
    // TODO #5
    FILE *output = fopen(argv[2], "w");
    if (output == NULL)
    {
        printf("Could not open file.\n");
        return 1;
    }

    // Write header to file
    // TODO #6
    size_t bytesWritten = fwrite(&header, 1, sizeof(WAVHEADER), output);
    if (bytesWritten != sizeof(WAVHEADER))
    {
        printf("Error writing header to output file");
        return 1;
    }

    // Use get_block_size to calculate size of block
    // TODO #7
    get_block_size(header);

    // Write reversed audio to file
    // TODO #8
    long data_start = HEADER_SIZE;
    long data_end = HEADER_SIZE + header.subchunk2Size;

    fseek(input, data_end - get_block_size(header), SEEK_SET);
    int16_t buffer;

    while (ftell(input) >= data_start)
    {
        // Read a block of data
        size_t bytesread = fread(&buffer, 1, get_block_size(header), input);
        if (bytesread != get_block_size(header))
        {
            printf("Error reading block.\n");
            break;
        }
        size_t readbytes = fwrite(&buffer, 1, get_block_size(header), output);
        fseek(input, -2 * get_block_size(header), SEEK_CUR);
    }
    //
    fclose(input);
    fclose(output);
}

int check_format(WAVHEADER header)
{
    // TODO #4
    if (strncmp((const char *) header.chunkID, "RIFF", 4) != 0)
    {
        printf("This is not a valid WAV file (RIFF missing)\n");
        return 1;
    }

    // Check the "WAVE" identifier after "RIFF"
    if (strncmp((const char *) header.format, "WAVE", 4) != 0)
    {
        printf("This is not a valid WAV file (WAVE missing)\n");
        return 1;
    }

    // Check the "fmt " chunk identifier (starts at byte 12)
    if (strncmp((const char *) header.subchunk1ID, "fmt ", 4) != 0)
    {
        printf("This is not a valid WAV file (fmt chunk missing)\n");
        return 1;
    }

    // Check the "data" chunk identifier (starts after the fmt chunk)
    if (strncmp((const char *) header.subchunk2ID, "data", 4) != 0)
    {
        printf("This is not a valid WAV file (data chunk missing)\n");
        return 1;
    }

    // Check if it's PCM format (audio_format == 1)
    if (header.audioFormat != 1)
    {
        printf("This is not a valid PCM WAV file.\n");
        return 1;
    }

    return 0;
}

int get_block_size(WAVHEADER header)
{
    // TODO #7
    int blockSize = header.numChannels * (header.bitsPerSample / 8);
    return blockSize;
}
