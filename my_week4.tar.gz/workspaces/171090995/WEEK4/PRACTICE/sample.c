#include <stdio.h>

typedef struct {
    int a;
    int b;
} Pair;

Pair swap(int a, int b);

int main(void)
{
    int x = 1;
    int y = 2;

    printf("x is %i, y is %i\n", x, y);

    // Get swapped values as a struct
    Pair swapped = swap(x, y);

    // Print the swapped values separately
    printf("x is %i, y is %i\n", swapped.a, swapped.b);

    return 0;
}

Pair swap(int a, int b)
{
    Pair result;
    result.a = b;
    result.b = a;
    return result;
}
