#include <cs50.h>
#include <stdio.h>

int main(void)
{
    // Get two strings
    char *s = get_string("s: ");
    char *t = get_string("t: ");
    printf("\n");

    // Print strings
    printf("%s\n", s);
    printf("%s\n", t);
    printf("\n");

    printf("%p\n", s);
    printf("%p\n", t);
     printf("\n");

    printf("%p\n", s+1);
    printf("%p\n", t+1);

}
