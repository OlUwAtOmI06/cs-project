void blur(int height, int width, RGBTRIPLE copy[height][width])
{
    RGBTRIPLE image[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = copy[i][j];
        }
    }
    //
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
        if (i == 0 && j == 0)
        {
            int red = (image[i][j].rgbtRed + image[i][j + 1].rgbtRed + image[i + 1][j].rgbtRed +image[i+ 1][j+ 1].rgbtRed ) / 4 ;
            int blue = (image[i][j].rgbtBlue + image[i][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue +image[i+ 1][j+ 1].rgbtBlue ) / 4 ;
            int green = (image[i][j].rgbtGreen + image[i][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen +image[i+ 1][j+ 1].rgbtGreen ) / 4 ;

            copy[i][j].rgbtRed = red;
            copy[i][j].rgbtBlue = blue;
            copy[i][j].rgbtGreen = green;

            // First pixel (top-left corner)
        }
        else if (i == height - 1 && j == width - 1)
        {
            int red = (image[i][j].rgbtRed + image[i][j - 1].rgbtRed + image[i - 1][j].rgbtRed +image[i- 1][j- 1].rgbtRed ) / 4 ;
            int blue = (image[i][j].rgbtBlue + image[i][j - 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j - 1].rgbtBlue ) / 4 ;
            int green = (image[i][j].rgbtGreen + image[i][j - 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j - 1].rgbtGreen ) / 4 ;

            copy[i][j].rgbtRed = red;
            copy[i][j].rgbtBlue = blue;
            copy[i][j].rgbtGreen = green;

            // Last pixel (bottom-right corner)
        }
        else if (i == 0)
        {
            int red = (image[i][j].rgbtRed + image[i][j + 1].rgbtRed + image[i + 1][j].rgbtRed +image[i+ 1][j+ 1].rgbtRed + image[i + 1][j-1].rgbtRed + image[i][j-1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue +image[i+ 1][j+ 1].rgbtBlue + image[i + 1][j-1].rgbtBlue + image[i][j-1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen +image[i+ 1][j+ 1].rgbtGreen + image[i + 1][j-1].rgbtGreen + image[i][j-1].rgbtGreen ) / 6 ;

            copy[i][j].rgbtRed = red;
            copy[i][j].rgbtBlue = blue;
            copy[i][j].rgbtGreen = green;

            // Top edge (excluding corners)
        }
        else if (i == height - 1)
        {
            int red = (image[i][j].rgbtRed + image[i][j - 1].rgbtRed + image[i - 1][j].rgbtRed +image[i - 1][j - 1].rgbtRed + image[i - 1][j+1].rgbtRed + image[i][j + 1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i][j - 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j - 1].rgbtBlue + image[i - 1][j +1].rgbtBlue + image[i][j + 1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i][j - 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j - 1].rgbtGreen + image[i - 1][j +1].rgbtGreen + image[i][j + 1].rgbtGreen ) / 6;

            copy[i][j].rgbtRed = red;
            copy[i][j].rgbtBlue = blue;
            copy[i][j].rgbtGreen = green;
            // Bottom edge (excluding corners)
        }
        else if (j == 0)
        {
            int red = (image[i][j].rgbtRed + image[i][j + 1].rgbtRed + image[i - 1][j].rgbtRed +image[i - 1][j + 1].rgbtRed + image[i + 1][j].rgbtRed + image[i+ 1][j + 1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i][j + 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue + image[i + 1][j + 1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i][j + 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen + image[i + 1][j + 1].rgbtGreen ) / 6;

            copy[i][j].rgbtRed = red;
            copy[i][j].rgbtBlue = blue;
            copy[i][j].rgbtGreen = green;
            // Left edge (excluding corners)
        }
        else if (j == width - 1)
        {
            int red = (image[i][j].rgbtRed + image[i +1][j ].rgbtRed + image[i - 1][j].rgbtRed +image[i + 1][j - 1].rgbtRed + image[i - 1][j - 1].rgbtRed + image[i][j - 1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i + 1][j ].rgbtBlue + image[i - 1][j].rgbtBlue +image[i + 1][j - 1].rgbtBlue + image[i - 1][j - 1].rgbtBlue + image[i][j - 1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i + 1][j].rgbtGreen + image[i - 1][j].rgbtGreen +image[i + 1][j - 1].rgbtGreen + image[i - 1][j - 1].rgbtGreen + image[i][j - 1].rgbtGreen ) / 6;

            copy[i][j].rgbtRed = red;
            copy[i][j].rgbtBlue = blue;
            copy[i][j].rgbtGreen = green;
            // Right edge (excluding corners)
        }
        else
        {
            int red = (image[i][j].rgbtRed + image[i][j - 1].rgbtRed + image[i - 1][j].rgbtRed +image[i - 1][j - 1].rgbtRed + image[i - 1][j+1].rgbtRed + image[i][j + 1].rgbtRed  + image[i + 1][j + 1].rgbtRed + image[i + 1][j].rgbtRed + image[i + 1][ j - 1].rgbtRed)/  9 ;
            int blue = (image[i][j].rgbtBlue + image[i][j - 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j - 1].rgbtBlue + image[i - 1][j +1].rgbtBlue + image[i][j + 1].rgbtBlue + image[i + 1][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue + image[i + 1][ j - 1].rgbtBlue)/  9 ;
            int green = (image[i][j].rgbtGreen + image[i][j - 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j - 1].rgbtGreen + image[i - 1][j +1].rgbtGreen + image[i][j + 1].rgbtGreen + image[i + 1][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen + image[i + 1][ j - 1].rgbtGreen)/  9 ;


            copy[i][j].rgbtRed = red;
            copy[i][j].rgbtBlue = blue;
            copy[i][j].rgbtGreen = green;
            // Not an edge pixel (internal pixel)
        }
        }
    }
   return;
}
// SAMPLE TEXT
for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
        if (i == 0 && j == 0)
        {
            int red = (image[i][j].rgbtRed + image[i][j + 1].rgbtRed + image[i + 1][j].rgbtRed +image[i+ 1][j+ 1].rgbtRed ) / 4 ;
            int blue = (image[i][j].rgbtBlue + image[i][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue +image[i+ 1][j+ 1].rgbtBlue ) / 4 ;
            int green = (image[i][j].rgbtGreen + image[i][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen +image[i+ 1][j+ 1].rgbtGreen ) / 4 ;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;

            // First pixel (top-left corner)
        }
        else if (i == height - 1 && j == width - 1)
        {
            int red = (image[i][j].rgbtRed + image[i][j - 1].rgbtRed + image[i - 1][j].rgbtRed +image[i- 1][j- 1].rgbtRed ) / 4 ;
            int blue = (image[i][j].rgbtBlue + image[i][j - 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j - 1].rgbtBlue ) / 4 ;
            int green = (image[i][j].rgbtGreen + image[i][j - 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j - 1].rgbtGreen ) / 4 ;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;

            // Last pixel (bottom-right corner)
        }
        else if (i == 0)
        {
            int red = (image[i][j].rgbtRed + image[i][j + 1].rgbtRed + image[i + 1][j].rgbtRed +image[i+ 1][j+ 1].rgbtRed + image[i + 1][j-1].rgbtRed + image[i][j-1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue +image[i+ 1][j+ 1].rgbtBlue + image[i + 1][j-1].rgbtBlue + image[i][j-1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen +image[i+ 1][j+ 1].rgbtGreen + image[i + 1][j-1].rgbtGreen + image[i][j-1].rgbtGreen ) / 6 ;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;

            // Top edge (excluding corners)
        }
        else if (i == height - 1)
        {
            int red = (image[i][j].rgbtRed + image[i][j - 1].rgbtRed + image[i - 1][j].rgbtRed +image[i - 1][j - 1].rgbtRed + image[i - 1][j+1].rgbtRed + image[i][j + 1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i][j - 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j - 1].rgbtBlue + image[i - 1][j +1].rgbtBlue + image[i][j + 1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i][j - 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j - 1].rgbtGreen + image[i - 1][j +1].rgbtGreen + image[i][j + 1].rgbtGreen ) / 6;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;
            // Bottom edge (excluding corners)
        }
        else if (j == 0)
        {
            int red = (image[i][j].rgbtRed + image[i][j + 1].rgbtRed + image[i - 1][j].rgbtRed +image[i - 1][j + 1].rgbtRed + image[i + 1][j].rgbtRed + image[i+ 1][j + 1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i][j + 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue + image[i + 1][j + 1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i][j + 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen + image[i + 1][j + 1].rgbtGreen ) / 6;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;
            // Left edge (excluding corners)
        }
        else if (j == width - 1)
        {
            int red = (image[i][j].rgbtRed + image[i +1][j ].rgbtRed + image[i - 1][j].rgbtRed +image[i + 1][j - 1].rgbtRed + image[i - 1][j - 1].rgbtRed + image[i][j - 1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i + 1][j ].rgbtBlue + image[i - 1][j].rgbtBlue +image[i + 1][j - 1].rgbtBlue + image[i - 1][j - 1].rgbtBlue + image[i][j - 1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i + 1][j].rgbtGreen + image[i - 1][j].rgbtGreen +image[i + 1][j - 1].rgbtGreen + image[i - 1][j - 1].rgbtGreen + image[i][j - 1].rgbtGreen ) / 6;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;
            // Right edge (excluding corners)
        }
        else
        {
            int red = (image[i][j].rgbtRed + image[i][j - 1].rgbtRed + image[i - 1][j].rgbtRed +image[i - 1][j - 1].rgbtRed + image[i - 1][j+1].rgbtRed + image[i][j + 1].rgbtRed  + image[i + 1][j + 1].rgbtRed + image[i + 1][j].rgbtRed + image[i + 1][ j - 1].rgbtRed)/  9 ;
            int blue = (image[i][j].rgbtBlue + image[i][j - 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j - 1].rgbtBlue + image[i - 1][j +1].rgbtBlue + image[i][j + 1].rgbtBlue + image[i + 1][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue + image[i + 1][ j - 1].rgbtBlue)/  9 ;
            int green = (image[i][j].rgbtGreen + image[i][j - 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j - 1].rgbtGreen + image[i - 1][j +1].rgbtGreen + image[i][j + 1].rgbtGreen + image[i + 1][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen + image[i + 1][ j - 1].rgbtGreen)/  9 ;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;
            // Not an edge pixel (internal pixel)
        }
        }
    }

     // FINALIZE
     // Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE copy[height][width];
    // Copy the original data into 'image' for reference

    for (int k = 0; k < height; k++)
    {
        for (int m = 0; m < width; m++)
        {
            copy[k][m] = image[k][m];
            }
            }
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int red = 0;
            int blue = 0;
            int green = 0;
            int count = 0;

    for(int a = i - 1 ; a <= i + 1 ; a ++){
        for(int b = j - 1 ;b <= j + 1 ; b ++){
            int ni = a + i; // neighbour i
            int nj = b + j; // neighbour j

            if (ni < 0) ni = 0;         // Top edge
            if (nj < 0) nj = 0;         // Left edge
            if (ni >= height) ni = height - 1; // Bottom edge
            if (nj >= width) nj = width - 1;  // Right edge
            // solution beginig
            if(a > 0 && b > 0 && a < height & b < width){
                red += copy[a][b].rgbtRed;
                blue += copy[a][b].rgbtBlue;
                green += copy[a][b].rgbtGreen;
                count ++;

            }
            //end

            red += copy[ni][nj].rgbtRed;
            blue += copy[ni][nj].rgbtBlue;
            green += copy[ni][nj].rgbtGreen;

            count++;
        }
            }
            image[i][j].rgbtRed = red  / count;
            image[i][j].rgbtBlue = blue  / count;
            image[i][j].rgbtGreen = green  / count;
                    }
    }
}
