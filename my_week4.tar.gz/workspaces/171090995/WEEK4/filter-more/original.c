void blur(int height, int width, RGBTRIPLE copy[height][width])
{
    RGBTRIPLE image[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j] = copy[i][j];
        }
    }
    //
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
        if (i == 0 && j == 0)
        {
            int red = (image[i][j].rgbtRed + image[i][j + 1].rgbtRed + image[i + 1][j].rgbtRed +image[i+ 1][j+ 1].rgbtRed ) / 4 ;
            int blue = (image[i][j].rgbtBlue + image[i][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue +image[i+ 1][j+ 1].rgbtBlue ) / 4 ;
            int green = (image[i][j].rgbtGreen + image[i][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen +image[i+ 1][j+ 1].rgbtGreen ) / 4 ;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;

            // First pixel (top-left corner)
        }
        else if (i == height - 1 && j == width - 1)
        {
            int red = (image[i][j].rgbtRed + image[i][j - 1].rgbtRed + image[i - 1][j].rgbtRed +image[i- 1][j- 1].rgbtRed ) / 4 ;
            int blue = (image[i][j].rgbtBlue + image[i][j - 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j - 1].rgbtBlue ) / 4 ;
            int green = (image[i][j].rgbtGreen + image[i][j - 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j - 1].rgbtGreen ) / 4 ;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;

            // Last pixel (bottom-right corner)
        }
        else if (i == 0)
        {
            int red = (image[i][j].rgbtRed + image[i][j + 1].rgbtRed + image[i + 1][j].rgbtRed +image[i+ 1][j+ 1].rgbtRed + image[i + 1][j-1].rgbtRed + image[i][j-1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue +image[i+ 1][j+ 1].rgbtBlue + image[i + 1][j-1].rgbtBlue + image[i][j-1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen +image[i+ 1][j+ 1].rgbtGreen + image[i + 1][j-1].rgbtGreen + image[i][j-1].rgbtGreen ) / 6 ;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;

            // Top edge (excluding corners)
        }
        else if (i == height - 1)
        {
            int red = (image[i][j].rgbtRed + image[i][j - 1].rgbtRed + image[i - 1][j].rgbtRed +image[i - 1][j - 1].rgbtRed + image[i - 1][j+1].rgbtRed + image[i][j + 1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i][j - 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j - 1].rgbtBlue + image[i - 1][j +1].rgbtBlue + image[i][j + 1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i][j - 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j - 1].rgbtGreen + image[i - 1][j +1].rgbtGreen + image[i][j + 1].rgbtGreen ) / 6;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;
            // Bottom edge (excluding corners)
        }
        else if (j == 0)
        {
            int red = (image[i][j].rgbtRed + image[i][j + 1].rgbtRed + image[i - 1][j].rgbtRed +image[i - 1][j + 1].rgbtRed + image[i + 1][j].rgbtRed + image[i+ 1][j + 1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i][j + 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue + image[i + 1][j + 1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i][j + 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen + image[i + 1][j + 1].rgbtGreen ) / 6;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;
            // Left edge (excluding corners)
        }
        else if (j == width - 1)
        {
            int red = (image[i][j].rgbtRed + image[i +1][j ].rgbtRed + image[i - 1][j].rgbtRed +image[i + 1][j - 1].rgbtRed + image[i - 1][j - 1].rgbtRed + image[i][j - 1].rgbtRed ) / 6 ;
            int blue = (image[i][j].rgbtBlue + image[i + 1][j ].rgbtBlue + image[i - 1][j].rgbtBlue +image[i + 1][j - 1].rgbtBlue + image[i - 1][j - 1].rgbtBlue + image[i][j - 1].rgbtBlue ) / 6 ;
            int green = (image[i][j].rgbtGreen + image[i + 1][j].rgbtGreen + image[i - 1][j].rgbtGreen +image[i + 1][j - 1].rgbtGreen + image[i - 1][j - 1].rgbtGreen + image[i][j - 1].rgbtGreen ) / 6;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;
            // Right edge (excluding corners)
        }
        else
        {
            int red = (image[i][j].rgbtRed + image[i][j - 1].rgbtRed + image[i - 1][j].rgbtRed +image[i - 1][j - 1].rgbtRed + image[i - 1][j+1].rgbtRed + image[i][j + 1].rgbtRed  + image[i + 1][j + 1].rgbtRed + image[i + 1][j].rgbtRed + image[i + 1][ j - 1].rgbtRed)/  9 ;
            int blue = (image[i][j].rgbtBlue + image[i][j - 1].rgbtBlue + image[i - 1][j].rgbtBlue +image[i - 1][j - 1].rgbtBlue + image[i - 1][j +1].rgbtBlue + image[i][j + 1].rgbtBlue + image[i + 1][j + 1].rgbtBlue + image[i + 1][j].rgbtBlue + image[i + 1][ j - 1].rgbtBlue)/  9 ;
            int green = (image[i][j].rgbtGreen + image[i][j - 1].rgbtGreen + image[i - 1][j].rgbtGreen +image[i - 1][j - 1].rgbtGreen + image[i - 1][j +1].rgbtGreen + image[i][j + 1].rgbtGreen + image[i + 1][j + 1].rgbtGreen + image[i + 1][j].rgbtGreen + image[i + 1][ j - 1].rgbtGreen)/  9 ;

            image[i][j].rgbtRed = red;
            image[i][j].rgbtBlue = blue;
            image[i][j].rgbtGreen = green;
            // Not an edge pixel (internal pixel)
        }
        }
    }
   return;
}


// ANOTHER
RGBTRIPLE copy;
    for(int i = 0; i < height; i++){
        for(int j = 0; j < width ; j++)
        {
            if( i - 1 < 0 || i + 1 == height){
                int count;
                for(int a = i ; a < i + 2 ; a++){
                    for(int b = i; b < i +2 ; b++){
                        copy =+ image[]
                    }

                }
            }
        }
    }

