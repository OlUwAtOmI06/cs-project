#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    int red;
    int blue;
    int green;

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            red = image[i][j].rgbtRed;
            blue = image[i][j].rgbtBlue;
            green = image[i][j].rgbtGreen;

            int total = (red + blue + green + 1) / 3;

            image[i][j].rgbtRed = total;
            image[i][j].rgbtBlue = total;
            image[i][j].rgbtGreen = total;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE temporary;
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width / 2; j++)
        {
            temporary = image[i][j];
            image[i][j] = image[i][width - j - 1];
            image[i][width - j - 1] = temporary;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE copy[height][width];
    // Copy the original data into 'image' for reference

    for (int k = 0; k < height; k++)
    {
        for (int m = 0; m < width; m++)
        {
            copy[k][m] = image[k][m];
        }
    }
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            float red = 0;
            float blue = 0;
            float green = 0;
            int count = 0;

            for (int a = i - 1; a <= i + 1; a++)
            {
                for (int b = j - 1; b <= j + 1; b++)
                {

                    if (a >= 0 && b >= 0 && a < height && b < width)
                    {
                        red += copy[a][b].rgbtRed;
                        blue += copy[a][b].rgbtBlue;
                        green += copy[a][b].rgbtGreen;
                        count++;
                    }
                }
            }
            image[i][j].rgbtRed = round(red / count);
            image[i][j].rgbtBlue = round(blue / count);
            image[i][j].rgbtGreen = round(green / count);
        }
    }
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE copy[height][width];
    // Copy the original data into 'image' for reference

    for (int k = 0; k < height; k++)
    {
        for (int m = 0; m < width; m++)
        {
            copy[k][m] = image[k][m];
        }
    }
    int Gx[3][3] = {{1, 0, -1}, {2, 0, -2}, {1, 0, -1}};
    int Gy[3][3] = {{1, 2, 1}, {0, 0, 0}, {-1, -2, -1}};

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            float red_Gx = 0;
            float blue_Gx = 0;
            float green_Gx = 0;
            float red_Gy = 0;
            float blue_Gy = 0;
            float green_Gy = 0;

            for (int a = -1; a <= 1; a++)
            {
                for (int b = -1; b <= 1; b++)
                {

                    if (i + a >= 0 && j + b >= 0 && i + a < height & j + b < width)
                    {
                        int value_a = a + 1;
                        int value_b = b + 1;

                        red_Gx += (Gx[value_a][value_b] * copy[i + a][j + b].rgbtRed);
                        blue_Gx += (Gx[value_a][value_b] * copy[i + a][j + b].rgbtBlue);
                        green_Gx += (Gx[value_a][value_b] * copy[i + a][j + b].rgbtGreen);
                        red_Gy += (Gy[value_a][value_b] * copy[i + a][j + b].rgbtRed);
                        blue_Gy += (Gy[value_a][value_b] * copy[i + a][j + b].rgbtBlue);
                        green_Gy += (Gy[value_a][value_b] * copy[i + a][j + b].rgbtGreen);
                    }
                }
            }
            // Calculate magnitude of gradients
            int result_red = round(sqrt(red_Gx * red_Gx + red_Gy * red_Gy));
            int result_blue = round(sqrt(blue_Gx * blue_Gx + blue_Gy * blue_Gy));
            int result_green = round(sqrt(green_Gx * green_Gx + green_Gy * green_Gy));

            // Clamp values to [0, 255]
            image[i][j].rgbtRed = result_red > 255 ? 255 : result_red;
            image[i][j].rgbtBlue = result_blue > 255 ? 255 : result_blue;
            image[i][j].rgbtGreen = result_green > 255 ? 255 : result_green;
        }
    }
}
