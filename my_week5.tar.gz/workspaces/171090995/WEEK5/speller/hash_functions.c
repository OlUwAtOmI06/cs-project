unsigned int hash(const char *word)
{
    int i = 1;
    int hash = 0;
    while (word[i -  1 ]) {
        hash +=(tolower(word[i]) * tolower(word[i - 1]));  // Add ASCII value of each character
        i ++;
    }
    hash += i;
    return hash % N;
    // TODO: Improve this hash function


}

//SECOND
unsigned int hash(const char *word)
{
    int i = 0;
    int hash = 0;
    while (word[i]) {
        if(i % 2 == 0){
            hash += tolower(word[i]) * 11;
            i++;
        }
        else {
            hash += tolower(word[i]) * 23;
            i++;
        }
    }
    hash += i;
    return hash % N;
    // TODO: Improve this hash function

}
